package app;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import javax.lang.model.SourceVersion;
import javax.lang.model.element.Name;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

import javafx.fxml.FXML;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.scene.control.Button;
import jfx.incubator.scene.control.richtext.RichTextArea;
import jfx.incubator.scene.control.richtext.model.StyleAttributeMap;

import com.sun.source.util.JavacTask;
import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.tree.ImportTree;
import com.sun.source.tree.ClassTree;
import com.sun.source.tree.MethodTree;
import com.sun.source.tree.Tree;
import com.sun.source.tree.VariableTree;

public class GuiController2 {

	@FXML
	RichTextArea textArea;
	@FXML
	Button openJava;

	StyleAttributeMap blue = StyleAttributeMap.builder().setBold(true).setFontFamily("Monospaced").setFontSize(12)
			.setTextColor(Color.CORNFLOWERBLUE).build();
	StyleAttributeMap green = StyleAttributeMap.builder().setBold(true).setFontFamily("Monospaced").setFontSize(12)
			.setTextColor(Color.GREEN).build();
	StyleAttributeMap grey = StyleAttributeMap.builder().setBold(true).setFontFamily("Monospaced").setFontSize(12)
			.setTextColor(Color.DIMGRAY).build();
	StyleAttributeMap red = StyleAttributeMap.builder().setBold(true).setFontFamily("Monospaced").setFontSize(12)
			.setTextColor(Color.RED).build();
	StyleAttributeMap dark = StyleAttributeMap.builder().setBold(true).setFontFamily("Monospaced").setFontSize(12)
			.setTextColor(Color.BLACK).build();

	
	Parser parser;
	public List<String> importsClass = new ArrayList<>();

	public GuiController2() {
	}

	public void initialize() {
		textArea.setEditable(true);

	}
	

	
	@FXML
	public void openJavaFile() {
		FileChooser chooser = new FileChooser();
		chooser.setInitialDirectory(new File(Path.of("./src/application").toAbsolutePath().toString()));
		chooser.setTitle("Select the first file");
		File file = chooser.showOpenDialog(null);
		parser = new Parser(file);
		processImports(parser.getImportTree());
		processVariables(parser.getVariableList());
	}

	private void processVariables(List<VariableTree> variableList) {
		for(VariableTree variable: variableList) {
			String line = variable.toString();
			textArea.appendText(variable.getModifiers().toString(), grey);
			textArea.appendText(variable.getType().toString() + " ", blue);
			textArea.appendText(variable.getName().toString(), green);
			if (variable.getInitializer() != null) {
				textArea.appendText(" = ");
				getClassFromString(variable.getInitializer().toString());
			}
			textArea.appendText(";\n");
		}
	}
	
	private void getClassFromString(String str) {
		//String test = "new StyleAttributeMap.builder().setBold(true).setFontSize(16).setFontFamily().setTextColor(Color.RED, Color.BLACK).build()";		
		//String test2 = "new SimpleObjectProperty<String s, Integer i>()";
		//str= test2;
		String[] words = str.split("(?=[ |\\.|\\(|,|<]+)"); // split on space , . ( < and the + is for them together; ?= keep the delimiter
		for(String s : words) {
			//System.out.println(s);
			int start = str.indexOf(s);
			int end = s.length();
			if (isCapitalize(s)) {
				System.out.println("found : " + s + " -  " + start + " - " + end);
				textArea.appendText(s.substring(0, end), blue);
			}else if ((s.charAt(0) == ' ' || s.charAt(0) == '<' || s.charAt(0) == '(') && isCapitalize(s.substring(1))) {
				textArea.appendText(s.substring(0, 1), grey);
				textArea.appendText(s.substring(1, end), blue);
			}else if (s.charAt(0) == '.' && Character.isLowerCase(s.charAt(1))) {
				textArea.appendText(s, green);
			} else {
				textArea.appendText(s, grey);
			}
		}
	}
	
	private static boolean isCapitalize(String str) {
		if (Character.isUpperCase(str.charAt(0)) && Character.isLowerCase(str.charAt(1))) {
			return true;
		}else return false;
	}

	private void processImports(List<? extends ImportTree> importTree) {
		for(ImportTree importLine: importTree) {
			String line = importLine.toString();
			textArea.appendText(line.substring(0, 6), red);
			textArea.appendText(line.substring(6), dark);
			importsClass.add(line.substring(line.lastIndexOf(".") + 1, line.trim().length()-1));
			//System.out.println(line.substring(line.lastIndexOf(".") + 1, line.trim().length()-1));
		}
		textArea.appendText("\n");
	}

}
